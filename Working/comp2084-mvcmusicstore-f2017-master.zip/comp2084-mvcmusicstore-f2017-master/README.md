<h1>COMP2084 - MVC Music Store - F2017</h1>

<p>This application uses ASP.NET MVC, SQL Server, Twitter Bootstrap and jQuery
as a learning tool for Georgian College's Server-Side Scripting Course.</p>

<p>Live site at <a href="http://comp2084-musicstore-f2017.azurewebsites.net">http://comp2084-musicstore-f2017.azurewebsites.net</a>